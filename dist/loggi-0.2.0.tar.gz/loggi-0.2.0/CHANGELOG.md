# Changelog

## v0.1.1 (2023-10-31)

#### Refactorings

* make logpath if it doesn't exist

## v0.1.0 (2023-10-29)

#### New Features

* add support for slicing Log objects and getting their event lengths
#### Fixes

* prevent duplicate log messages


