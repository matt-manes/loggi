# Changelog

## v0.1.0 (2023-10-29)

#### New Features

* add support for slicing Log objects and getting their event lengths
#### Fixes

* prevent duplicate log messages


